from kivymd.uix.screen import MDScreen

from apputils import load_kv

load_kv(__name__)


class Two(MDScreen):
    pass
