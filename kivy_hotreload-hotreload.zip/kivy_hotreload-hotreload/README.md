## Example code for enabling the hot reload feature of KivyMD

- The **[main](https://github.com/JennaSys/kivy_hotreload/tree/main)** branch has example Kivy project without hot reloading
- The **[hotreload](https://github.com/JennaSys/kivy_hotreload/tree/hotreload)** branch has the changes required to enable hot reloading

_The key differences between the two branches are in main.py and apputils.py_
